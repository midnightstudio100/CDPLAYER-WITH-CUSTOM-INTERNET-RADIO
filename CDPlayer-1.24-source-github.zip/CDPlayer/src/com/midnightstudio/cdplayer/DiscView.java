package com.midnightstudio.cdplayer;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.SweepGradient;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;

/**
 * Draws the CD from the user's reference photo: a black jewel case with a
 * ribbed spine on the left, an iridescent rainbow disc, a grey center hub,
 * and curved text around the disc edge. The whole disc rotates with the
 * playback angle (4s per revolution, driven by the Activity tick); the
 * jewel case stays still.
 */
public class DiscView extends View {

    private static final String RING_TEXT = "DESIGNED BY MIDNIGHT STUDIO  \u2022  ";
    private static final int[] RAINBOW = {
            0xFFF3D9E6, 0xFFE7E1F8, 0xFFDDF0F6, 0xFFF6F1D3,
            0xFFE5F3DD, 0xFFF3D9E6
    };

    private final Paint casePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint edgePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint spinePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint discPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hubPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint holePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final TextPaint titlePaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final Path textPath = new Path();
    private final Path titlePath = new Path();
    private final RectF caseRect = new RectF();

    private float angle = 0f;
    private String title = "";

    public DiscView(Context ctx) { super(ctx); init(); }
    public DiscView(Context ctx, AttributeSet attrs) { super(ctx, attrs); init(); }

    private void init() {
        casePaint.setColor(0xFF141414);
        casePaint.setStyle(Paint.Style.FILL);
        edgePaint.setColor(0xFF3A3A3A);
        edgePaint.setStyle(Paint.Style.STROKE);
        edgePaint.setStrokeWidth(3f);
        spinePaint.setColor(0xFF232323);
        spinePaint.setStyle(Paint.Style.FILL);
        ringPaint.setColor(0xFF3A3A3A);
        ringPaint.setStyle(Paint.Style.STROKE);
        ringPaint.setStrokeWidth(2f);
        hubPaint.setColor(0xFF6E6E6E);
        hubPaint.setStyle(Paint.Style.FILL);
        holePaint.setColor(0xFF1A1A1A);
        holePaint.setStyle(Paint.Style.FILL);
        textPaint.setColor(0xFF8A8A8A);
        textPaint.setTextSize(30f);
        textPaint.setFakeBoldText(true);
        // Song title drawn curved in a circle on the disc, spinning
        // with the disc: dark text with a white glow so it reads over
        // the light iridescent disc.
        titlePaint.setColor(0xFF1A1A1A);
        titlePaint.setFakeBoldText(true);
        titlePaint.setShadowLayer(6f, 0f, 0f, 0xFFFFFFFF);
    }

    public void setAngle(float angle) {
        this.angle = angle;
        invalidate();
    }

    /** Current song/station title, drawn curved in a circle on the disc (spins with the disc). */
    public void setTitle(String title) {
        this.title = title == null ? "" : title;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w = getWidth();
        float h = getHeight();
        float cx = w / 2f;
        float cy = h / 2f;
        float discR = Math.min(w, h) / 2f - dp(6);

        // Jewel case: black rounded rect with a lighter edge.
        caseRect.set(dp(2), dp(2), w - dp(2), h - dp(2));
        c.drawRoundRect(caseRect, dp(10), dp(10), casePaint);
        c.drawRoundRect(caseRect, dp(10), dp(10), edgePaint);
        // Ribbed spine on the left, like the photo.
        float spineW = w * 0.09f;
        c.drawRect(dp(2), dp(2), spineW, h - dp(2), spinePaint);
        for (float x = dp(6); x < spineW - dp(2); x += dp(5)) {
            c.drawLine(x, dp(4), x, h - dp(4), edgePaint);
        }

        // The whole disc spins with the playback angle (4s per revolution):
        // rainbow sweep, rings, ring text, hub, hole and star teeth all
        // rotate together inside one save/rotate/restore. The jewel case
        // and ribbed spine above stay static.
        c.save();
        c.rotate(angle, cx, cy);

        // Iridescent disc: pastel rainbow sweep. The sweep gradient is
        // angular, so it rotates with the canvas.
        SweepGradient sg = new SweepGradient(cx, cy, RAINBOW, null);
        discPaint.setShader(sg);
        c.drawCircle(cx, cy, discR, discPaint);
        discPaint.setShader(null);

        // Thin rings marking the data area edge.
        c.drawCircle(cx, cy, discR * 0.97f, ringPaint);
        c.drawCircle(cx, cy, discR * 0.34f, ringPaint);

        // Curved text around the disc edge.
        textPath.reset();
        float textR = discR * 0.82f;
        textPath.addCircle(cx, cy, textR, Path.Direction.CW);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 3; i++) sb.append(RING_TEXT);
        c.drawTextOnPath(sb.toString(), textPath, 0, 0, textPaint);

        // Grey center hub with star-shaped center hole.
        float hubR = discR * 0.30f;
        c.drawCircle(cx, cy, hubR, hubPaint);
        c.drawCircle(cx, cy, hubR * 0.55f, ringPaint);
        float holeR = hubR * 0.34f;
        c.drawCircle(cx, cy, holeR, holePaint);
        // Star teeth around the hole.
        float toothLen = holeR * 0.45f;
        for (int i = 0; i < 12; i++) {
            double a = Math.toRadians(i * 30);
            float x0 = cx + (float) (Math.cos(a) * holeR * 0.85f);
            float y0 = cy + (float) (Math.sin(a) * holeR * 0.85f);
            float x1 = cx + (float) (Math.cos(a) * (holeR + toothLen));
            float y1 = cy + (float) (Math.sin(a) * (holeR + toothLen));
            c.drawLine(x0, y0, x1, y1, holePaint);
        }
        // Center dot.
        c.drawCircle(cx, cy, holeR * 0.35f, hubPaint);

        // Song title, drawn CURVED in a circle like the ring text,
        // INSIDE the rotation so it spins with the disc. The circular
        // path sits at 0.70*discR, in the middle band between the hub
        // (0.30*discR) and the ring text (0.82*discR), so it overlaps
        // neither. The title is drawn once, centered at the TOP of the
        // circle: the path starts at 3 o'clock and runs clockwise, so
        // the top is at 0.75 * circumference along the path. Sized to
        // fit the TOP SEMICIRCLE only: the cap is 50% of the
        // circumference, so with the top centering the title spans from
        // 9 o'clock over the top to 3 o'clock and never goes below the
        // horizontal diameter: it never turns upside down at the bottom
        // and never overlaps the ring text there. Shrunk / ellipsized
        // to that cap. Skipped when empty.
        if (title != null && !title.isEmpty()) {
            float titleR = discR * 0.70f;
            double circumference = 2.0 * Math.PI * titleR;
            float maxW = (float) (circumference * 0.5);
            float size = discR * 0.13f;
            titlePaint.setTextSize(size);
            if (titlePaint.measureText(title) > maxW) {
                float shrunk = size * maxW / titlePaint.measureText(title);
                float minSize = discR * 0.05f;
                if (shrunk < minSize) shrunk = minSize;
                titlePaint.setTextSize(shrunk);
            }
            CharSequence shown = title;
            if (titlePaint.measureText(title) > maxW) {
                shown = TextUtils.ellipsize(title, titlePaint, maxW,
                        TextUtils.TruncateAt.END);
            }
            String line = shown.toString();
            titlePath.reset();
            titlePath.addCircle(cx, cy, titleR, Path.Direction.CW);
            float hOffset = (float) (circumference * 0.75
                    - titlePaint.measureText(line) / 2.0);
            c.drawTextOnPath(line, titlePath, hOffset, 0, titlePaint);
        }

        c.restore();
    }

    private float dp(float v) {
        return v * getResources().getDisplayMetrics().density;
    }
}
