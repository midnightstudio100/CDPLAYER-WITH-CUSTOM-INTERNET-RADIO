package com.midnightstudio.cdplayer;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

/**
 * Draws a cassette: dark body, label, tape window with two reels whose
 * spokes rotate with the playback angle (4s per revolution, driven by the
 * Activity tick). Switching to this view never touches playback.
 */
public class CassetteView extends View {

    private final Paint bodyPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint edgePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint labelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint windowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint reelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hubPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tapePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();

    private float angle = 0f;

    public CassetteView(Context ctx) { super(ctx); init(); }
    public CassetteView(Context ctx, AttributeSet attrs) { super(ctx, attrs); init(); }

    private void init() {
        bodyPaint.setColor(0xFF1E1E1E);
        bodyPaint.setStyle(Paint.Style.FILL);
        edgePaint.setColor(0xFF3A3A3A);
        edgePaint.setStyle(Paint.Style.STROKE);
        edgePaint.setStrokeWidth(3f);
        labelPaint.setColor(0xFFF2EDE3);
        labelPaint.setStyle(Paint.Style.FILL);
        windowPaint.setColor(0xFF0A0A0A);
        windowPaint.setStyle(Paint.Style.FILL);
        reelPaint.setColor(0xFFE8E8E8);
        reelPaint.setStyle(Paint.Style.FILL);
        hubPaint.setColor(0xFF333333);
        hubPaint.setStyle(Paint.Style.FILL);
        tapePaint.setColor(0xFF4A3220);
        tapePaint.setStyle(Paint.Style.STROKE);
        tapePaint.setStrokeWidth(6f);
        textPaint.setColor(0xFF333333);
        textPaint.setTextSize(28f);
        textPaint.setFakeBoldText(true);
        textPaint.setTextAlign(Paint.Align.CENTER);
    }

    public void setAngle(float angle) {
        this.angle = angle;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w = getWidth();
        float h = getHeight();

        // Body.
        rect.set(dp(4), dp(4), w - dp(4), h - dp(4));
        c.drawRoundRect(rect, dp(14), dp(14), bodyPaint);
        c.drawRoundRect(rect, dp(14), dp(14), edgePaint);

        // Label area.
        float labelTop = h * 0.10f;
        float labelBottom = h * 0.52f;
        rect.set(w * 0.08f, labelTop, w * 0.92f, labelBottom);
        c.drawRoundRect(rect, dp(8), dp(8), labelPaint);
        c.drawText("MIDNIGHT STUDIO", w / 2f, labelTop + dp(30), textPaint);
        c.drawText("CD PLAYER", w / 2f, labelTop + dp(62), textPaint);

        // Tape window.
        float winTop = h * 0.58f;
        float winBottom = h * 0.88f;
        rect.set(w * 0.10f, winTop, w * 0.90f, winBottom);
        c.drawRoundRect(rect, dp(10), dp(10), windowPaint);

        float winCx = w / 2f;
        float winCy = (winTop + winBottom) / 2f;
        float reelR = (winBottom - winTop) * 0.32f;
        float reelDx = w * 0.22f;
        float leftX = winCx - reelDx;
        float rightX = winCx + reelDx;

        // Tape band between the reels.
        c.drawLine(leftX, winCy, rightX, winCy, tapePaint);

        drawReel(c, leftX, winCy, reelR, angle);
        drawReel(c, rightX, winCy, reelR, -angle);
    }

    private void drawReel(Canvas c, float cx, float cy, float r, float a) {
        c.drawCircle(cx, cy, r, reelPaint);
        c.drawCircle(cx, cy, r * 0.55f, hubPaint);
        // Three spokes, rotating with the angle.
        for (int i = 0; i < 3; i++) {
            double rad = Math.toRadians(a + i * 120);
            float x1 = cx + (float) (Math.cos(rad) * r * 0.6f);
            float y1 = cy + (float) (Math.sin(rad) * r * 0.6f);
            float x2 = cx + (float) (Math.cos(rad) * r * 0.95f);
            float y2 = cy + (float) (Math.sin(rad) * r * 0.95f);
            c.drawLine(x1, y1, x2, y2, hubPaint);
        }
        c.drawCircle(cx, cy, r * 0.18f, reelPaint);
    }

    private float dp(float v) {
        return v * getResources().getDisplayMetrics().density;
    }
}
