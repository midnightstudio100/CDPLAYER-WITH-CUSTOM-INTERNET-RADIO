package com.midnightstudio.cdplayer;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * Reads SHOUTcast/Icecast ICY metadata (StreamTitle) from a radio stream in
 * parallel with MediaPlayer. MediaPlayer does not expose ICY titles, so this
 * small reader opens the same URL with an Icy-MetaData request and parses the
 * metadata blocks. Runs on its own thread; call stop() to end it.
 */
public class IcyReader extends Thread {

    public interface Listener {
        void onTitle(String title);
    }

    private final String url;
    private final Listener listener;
    private volatile boolean stopped = false;

    public IcyReader(String url, Listener listener) {
        this.url = url;
        this.listener = listener;
        setDaemon(true);
    }

    public void stopReading() {
        stopped = true;
        interrupt();
    }

    @Override
    public void run() {
        HttpURLConnection conn = null;
        InputStream in = null;
        try {
            conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setRequestProperty("Icy-MetaData", "1");
            conn.setRequestProperty("User-Agent", "CDPlayer/1.0");
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(15000);
            conn.setInstanceFollowRedirects(true);
            conn.connect();

            int metaInt = 0;
            String header = conn.getHeaderField("icy-metaint");
            if (header != null) {
                try { metaInt = Integer.parseInt(header.trim()); } catch (NumberFormatException ignored) {}
            }
            in = conn.getInputStream();
            if (metaInt <= 0) {
                // No metadata on this stream; nothing to report.
                return;
            }
            byte[] buf = new byte[8192];
            int audioLeft = metaInt;
            String lastTitle = null;
            while (!stopped) {
                int toRead = Math.min(buf.length, audioLeft);
                int n = in.read(buf, 0, toRead);
                if (n < 0) break;
                audioLeft -= n;
                if (audioLeft > 0) continue;
                // Metadata block follows.
                int lenByte = in.read();
                if (lenByte < 0) break;
                int metaLen = lenByte * 16;
                if (metaLen > 0) {
                    byte[] meta = new byte[metaLen];
                    int off = 0;
                    while (off < metaLen) {
                        int r = in.read(meta, off, metaLen - off);
                        if (r < 0) break;
                        off += r;
                    }
                    String title = parseTitle(new String(meta, 0, off, StandardCharsets.UTF_8));
                    if (title != null && !title.equals(lastTitle)) {
                        lastTitle = title;
                        if (listener != null) listener.onTitle(title);
                    }
                }
                audioLeft = metaInt;
            }
        } catch (Exception ignored) {
            // Stream closed, network hiccup, or stop requested: silent exit.
        } finally {
            try { if (in != null) in.close(); } catch (Exception ignored) {}
            if (conn != null) conn.disconnect();
        }
    }

    /** Extract StreamTitle='...' from a metadata block. Returns null if absent. */
    private static String parseTitle(String meta) {
        int s = meta.indexOf("StreamTitle='");
        if (s < 0) return null;
        int start = s + "StreamTitle='".length();
        int end = meta.indexOf("';", start);
        if (end < 0) return null;
        String t = meta.substring(start, end).trim();
        return t.isEmpty() ? null : t;
    }
}
