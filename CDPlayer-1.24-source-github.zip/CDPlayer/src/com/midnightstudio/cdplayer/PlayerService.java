package com.midnightstudio.cdplayer;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.bluetooth.BluetoothClass;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Foreground playback service: local music and user-added radio streams.
 * All code here is original, written for this app. No preset stations.
 *
 * - Persists last track/station with commit() on every play path; restores
 *   on create but never auto-plays.
 * - Refreshes notification + MediaSession metadata on every ICY title.
 * - 1-second ticker re-broadcasts live state so the Activity re-syncs.
 * - Bluetooth audio-device disconnect pauses (playing/buffering only),
 *   never auto-resumes. Default ON.
 */
public class PlayerService extends Service
        implements MediaPlayer.OnPreparedListener,
                   MediaPlayer.OnCompletionListener,
                   MediaPlayer.OnErrorListener {

    public static final String ACTION_STATE =
            "com.midnightstudio.cdplayer.STATE";
    public static final String ACTION_PLAY = "com.midnightstudio.cdplayer.PLAY";
    public static final String ACTION_PAUSE = "com.midnightstudio.cdplayer.PAUSE";
    public static final String ACTION_NEXT = "com.midnightstudio.cdplayer.NEXT";
    public static final String ACTION_PREV = "com.midnightstudio.cdplayer.PREV";

    public static final int KIND_NONE = 0;
    public static final int KIND_LOCAL = 1;
    public static final int KIND_RADIO = 2;

    public static final int REPEAT_OFF = 0;
    public static final int REPEAT_ALL = 1;
    public static final int REPEAT_ONE = 2;

    private static final String PREFS = "cdplayer_prefs";
    private static final String CH_ID = "playback";
    private static final int NOTIF_ID = 1;

    private final IBinder binder = new LocalBinder();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final Random random = new Random();

    private MediaPlayer player;
    private MediaSession session;
    private AudioManager audioManager;
    private AudioFocusRequest focusRequest;
    private NotificationManager notifManager;
    private SharedPreferences prefs;

    private boolean prepared = false;
    private boolean playing = false;
    private boolean buffering = false;
    private int kind = KIND_NONE;

    private List<Song> songs = new ArrayList<>();
    private int songIndex = -1;
    private Song currentSong = null;

    private List<Station> stations = new ArrayList<>();
    private int stationIndex = -1;
    private Station currentStation = null;

    private String currentTitle = "";
    private String currentArtist = "";
    private String icyTitle = null;

    private boolean shuffle = false;
    private int repeat = REPEAT_OFF;
    private boolean btPause = true;

    private IcyReader icyReader = null;
    private boolean tickerRunning = false;

    public class LocalBinder extends Binder {
        public PlayerService getService() { return PlayerService.this; }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        shuffle = prefs.getBoolean("shuffle", false);
        repeat = prefs.getInt("repeat", REPEAT_OFF);
        btPause = prefs.getBoolean("bt_pause", true);
        stations = Station.parse(prefs.getString("stations", "[]"));

        audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        notifManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        createChannel();

        player = new MediaPlayer();
        try {
            player.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build());
        } catch (Exception ignored) {}
        try { player.setWakeMode(getApplicationContext(), PowerManager.PARTIAL_WAKE_LOCK); }
        catch (Exception ignored) {}
        player.setOnPreparedListener(this);
        player.setOnCompletionListener(this);
        player.setOnErrorListener(this);

        session = new MediaSession(this, "CDPlayerSession");
        session.setCallback(new MediaSession.Callback() {
            @Override public void onPlay() { resume(); }
            @Override public void onPause() { pause(); }
            @Override public void onSkipToNext() { next(); }
            @Override public void onSkipToPrevious() { prev(); }
            @Override public void onSeekTo(long pos) { seekTo((int) pos); }
            @Override public void onStop() { pause(); }
        });
        session.setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS
                | MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS);
        session.setActive(true);

        // Restore last selection for display only. Never auto-play.
        try {
            int lastKind = prefs.getInt("last_kind", KIND_NONE);
            if (lastKind == KIND_RADIO) {
                int idx = prefs.getInt("last_station", -1);
                if (idx >= 0 && idx < stations.size()) {
                    kind = KIND_RADIO;
                    stationIndex = idx;
                    currentStation = stations.get(idx);
                    currentTitle = currentStation.name;
                    currentArtist = currentStation.name;
                }
            } else if (lastKind == KIND_LOCAL) {
                long id = prefs.getLong("last_song_id", -1);
                if (id >= 0) {
                    kind = KIND_LOCAL;
                    currentTitle = prefs.getString("last_song_title", "");
                    currentArtist = prefs.getString("last_song_artist", "");
                }
            }
        } catch (Exception ignored) {}

        // Android 14+ (API 34+) requires dynamically-registered receivers to
        // declare exported-ness; the 2-arg registerReceiver throws
        // SecurityException when targeting API 34+. Only this app / the
        // system Bluetooth stack sends here, so NOT_EXPORTED is correct.
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(btReceiver,
                    new IntentFilter(BluetoothDevice.ACTION_ACL_DISCONNECTED),
                    Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(btReceiver, new IntentFilter(BluetoothDevice.ACTION_ACL_DISCONNECTED));
        }
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, buildNotification(),
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(NOTIF_ID, buildNotification());
        }
        startTicker();
        updateSession();
        broadcastState();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getAction() != null) {
            String a = intent.getAction();
            try {
                if (ACTION_PLAY.equals(a)) resume();
                else if (ACTION_PAUSE.equals(a)) pause();
                else if (ACTION_NEXT.equals(a)) next();
                else if (ACTION_PREV.equals(a)) prev();
            } catch (Exception ignored) {}
        }
        // Plain start with no action: ignore (no resume from a bare intent).
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) { return binder; }

    @Override
    public void onDestroy() {
        super.onDestroy();
        tickerRunning = false;
        mainHandler.removeCallbacks(ticker);
        stopIcy();
        try { unregisterReceiver(btReceiver); } catch (Exception ignored) {}
        try { if (player != null) { player.stop(); player.release(); } } catch (Exception ignored) {}
        player = null;
        try { if (session != null) { session.setActive(false); session.release(); } } catch (Exception ignored) {}
        try { if (focusRequest != null) audioManager.abandonAudioFocusRequest(focusRequest); } catch (Exception ignored) {}
        try { stopForeground(true); } catch (Exception ignored) {}
    }

    // ---------- playback API (called by Activity / session / notification) ----------

    public synchronized void playSong(Song song, List<Song> list, int index) {
        if (song == null) return;
        songs = list != null ? new ArrayList<>(list) : new ArrayList<Song>();
        songIndex = index;
        currentSong = song;
        kind = KIND_LOCAL;
        currentStation = null;
        stationIndex = -1;
        icyTitle = null;
        startPlayback(song.uri, false);
        currentTitle = song.title;
        currentArtist = song.artist;
        saveLast();
        updateSession();
        broadcastState();
    }

    public synchronized void playStation(Station station, List<Station> list, int index) {
        if (station == null) return;
        stations = list != null ? new ArrayList<>(list) : new ArrayList<Station>();
        stationIndex = index;
        currentStation = station;
        kind = KIND_RADIO;
        currentSong = null;
        songIndex = -1;
        icyTitle = null;
        currentTitle = station.name;
        currentArtist = station.name;
        // Show the last-known song title for this station right away; the
        // fresh ICY title overwrites it when it arrives (onIcyTitle).
        String lastTitle = prefs.getString("icy_" + station.url, null);
        if (lastTitle != null && !lastTitle.isEmpty()) {
            currentTitle = lastTitle;
        }
        startPlayback(station.url, true);
        saveLast();
        updateSession();
        broadcastState();
    }

    /**
     * Local song: pass the content Uri object. setDataSource(String) on a
     * content:// URI does not reliably grant the media server access to the
     * file under scoped storage (Android 17), so prepareAsync fails silently
     * and playback never starts. setDataSource(Context, Uri) is required.
     */
    private void startPlayback(Uri uri, boolean isRadio) {
        startPlaybackInternal(uri, null, isRadio);
    }

    /** Radio stream: http/https URL string (unchanged). */
    private void startPlayback(String source, boolean isRadio) {
        startPlaybackInternal(null, source, isRadio);
    }

    private void startPlaybackInternal(Uri uri, String source, boolean isRadio) {
        stopIcy();
        try { player.reset(); } catch (Exception ignored) {}
        prepared = false;
        buffering = true;
        playing = false;
        try {
            if (uri != null) player.setDataSource(getApplicationContext(), uri);
            else player.setDataSource(source);
            if (isRadio) startIcy();
            player.prepareAsync();
        } catch (Exception e) {
            buffering = false;
            broadcastError();
            return;
        }
        requestFocus();
        refreshNotification();
    }

    public synchronized void resume() {
        if (kind == KIND_NONE) return;
        if (prepared) {
            try {
                requestFocus();
                player.start();
                playing = true;
                buffering = false;
            } catch (Exception ignored) {}
        } else {
            // Player was reset (e.g. after error): restart the current item.
            if (kind == KIND_LOCAL && currentSong != null) {
                playSong(currentSong, songs, songIndex);
                return;
            }
            if (kind == KIND_RADIO && currentStation != null) {
                playStation(currentStation, stations, stationIndex);
                return;
            }
        }
        updateSession();
        broadcastState();
        refreshNotification();
    }

    public synchronized void pause() {
        try {
            if (player != null && prepared && player.isPlaying()) player.pause();
        } catch (Exception ignored) {}
        playing = false;
        buffering = false;
        updateSession();
        broadcastState();
        refreshNotification();
    }

    public synchronized void togglePlayPause() {
        if (playing) pause(); else resume();
    }

    public synchronized void next() {
        try {
            if (kind == KIND_LOCAL && !songs.isEmpty()) {
                int n = nextSongIndex(true);
                if (n >= 0) playSong(songs.get(n), songs, n);
            } else if (kind == KIND_RADIO && !stations.isEmpty()) {
                int n = (stationIndex + 1) % stations.size();
                playStation(stations.get(n), stations, n);
            }
        } catch (Exception ignored) {}
    }

    public synchronized void prev() {
        try {
            if (kind == KIND_LOCAL && !songs.isEmpty()) {
                if (getSafePosition() > 3000) {
                    seekTo(0);
                    return;
                }
                int n = songIndex - 1;
                if (n < 0) n = songs.size() - 1;
                playSong(songs.get(n), songs, n);
            } else if (kind == KIND_RADIO && !stations.isEmpty()) {
                int n = stationIndex - 1;
                if (n < 0) n = stations.size() - 1;
                playStation(stations.get(n), stations, n);
            }
        } catch (Exception ignored) {}
    }

    public synchronized void seekTo(int ms) {
        try {
            if (player != null && prepared && kind == KIND_LOCAL) {
                int d = getSafeDuration();
                if (d > 0) ms = Math.max(0, Math.min(ms, d));
                player.seekTo(ms);
            }
        } catch (Exception ignored) {}
        updateSession();
        broadcastState();
    }

    public synchronized void toggleShuffle() {
        shuffle = !shuffle;
        prefs.edit().putBoolean("shuffle", shuffle).commit();
        broadcastState();
    }

    public synchronized void cycleRepeat() {
        repeat = (repeat + 1) % 3;
        prefs.edit().putInt("repeat", repeat).commit();
        broadcastState();
    }

    public void setSongList(List<Song> list) {
        songs = list != null ? new ArrayList<>(list) : new ArrayList<Song>();
    }

    public void setStationList(List<Station> list) {
        stations = list != null ? new ArrayList<>(list) : new ArrayList<Station>();
        // Keep the restored station index valid after the list arrives.
        if (kind == KIND_RADIO && currentStation != null) {
            int idx = -1;
            for (int i = 0; i < stations.size(); i++) {
                if (stations.get(i).url.equals(currentStation.url)) { idx = i; break; }
            }
            if (idx >= 0) stationIndex = idx;
        }
    }

    // ---------- guarded position/duration (never crash during Preparing) ----------

    public int getSafePosition() {
        try {
            if (player != null && prepared && kind == KIND_LOCAL) return player.getCurrentPosition();
        } catch (Exception ignored) {}
        return -1;
    }

    public int getSafeDuration() {
        try {
            if (player != null && prepared && kind == KIND_LOCAL) return player.getDuration();
        } catch (Exception ignored) {}
        return -1;
    }

    public boolean isPlaying() { return playing; }
    public boolean isBuffering() { return buffering; }
    public boolean isRadio() { return kind == KIND_RADIO; }
    public boolean isLocal() { return kind == KIND_LOCAL; }
    public boolean isPrepared() { return prepared; }
    public int getKind() { return kind; }
    public Song getCurrentSong() { return currentSong; }
    public int getSongIndex() { return songIndex; }
    public Station getCurrentStation() { return currentStation; }
    public int getStationIndex() { return stationIndex; }
    public String getCurrentTitle() { return currentTitle; }
    public String getCurrentArtist() { return currentArtist; }
    public boolean isShuffle() { return shuffle; }
    public int getRepeat() { return repeat; }
    public boolean isBtPause() { return btPause; }

    public void setBtPause(boolean v) {
        btPause = v;
        prefs.edit().putBoolean("bt_pause", btPause).commit();
    }

    // ---------- MediaPlayer callbacks ----------

    @Override
    public void onPrepared(MediaPlayer mp) {
        prepared = true;
        buffering = false;
        try {
            mp.start();
            playing = true;
        } catch (Exception ignored) {}
        updateSession();
        broadcastState();
        refreshNotification();
    }

    @Override
    public void onCompletion(MediaPlayer mp) {
        if (kind != KIND_LOCAL) return;
        if (repeat == REPEAT_ONE) {
            try { mp.seekTo(0); mp.start(); playing = true; } catch (Exception ignored) {}
            updateSession();
            broadcastState();
            return;
        }
        int n = nextSongIndex(false);
        if (n >= 0) {
            playSong(songs.get(n), songs, n);
        } else {
            playing = false;
            try { mp.seekTo(0); } catch (Exception ignored) {}
            updateSession();
            broadcastState();
            refreshNotification();
        }
    }

    @Override
    public boolean onError(MediaPlayer mp, int what, int extra) {
        prepared = false;
        playing = false;
        buffering = false;
        stopIcy();
        updateSession();
        broadcastError();
        refreshNotification();
        return true;
    }

    private int nextSongIndex(boolean manual) {
        if (songs.isEmpty()) return -1;
        if (shuffle && songs.size() > 1) {
            int n;
            do { n = random.nextInt(songs.size()); } while (n == songIndex);
            return n;
        }
        int n = songIndex + 1;
        if (n >= songs.size()) {
            if (repeat == REPEAT_ALL || manual) return 0;
            return -1;
        }
        return n;
    }

    // ---------- ICY metadata ----------

    private void startIcy() {
        stopIcy();
        if (currentStation == null) return;
        final String url = currentStation.url;
        icyReader = new IcyReader(url, new IcyReader.Listener() {
            @Override public void onTitle(final String title) {
                mainHandler.post(new Runnable() {
                    @Override public void run() { onIcyTitle(title); }
                });
            }
        });
        icyReader.start();
    }

    private void stopIcy() {
        if (icyReader != null) {
            icyReader.stopReading();
            icyReader = null;
        }
    }

    private synchronized void onIcyTitle(String title) {
        if (kind != KIND_RADIO || title == null || title.isEmpty()) return;
        icyTitle = title;
        currentTitle = title;
        currentArtist = currentStation != null ? currentStation.name : "";
        // Remember the last song title for this station, so the next time
        // the user taps it the title shows right away (before the first
        // fresh ICY title arrives).
        if (currentStation != null && currentStation.url != null) {
            prefs.edit().putString("icy_" + currentStation.url, title).commit();
        }
        // Refresh every display from this one event: notification, session, app.
        updateSession();
        mainHandler.post(new Runnable() {
            @Override public void run() { refreshNotification(); }
        });
        broadcastState();
    }

    // ---------- persistence (commit: must survive a kill right after leaving) ----------

    private void saveLast() {
        SharedPreferences.Editor e = prefs.edit();
        e.putInt("last_kind", kind);
        if (kind == KIND_LOCAL && currentSong != null) {
            e.putLong("last_song_id", currentSong.id);
            e.putString("last_song_title", currentSong.title);
            e.putString("last_song_artist", currentSong.artist);
        } else if (kind == KIND_RADIO && currentStation != null) {
            e.putInt("last_station", stationIndex);
        }
        e.commit();
    }

    // ---------- notification + MediaSession ----------

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(
                    CH_ID, getString(R.string.notif_channel),
                    NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("CD Player");
            try { notifManager.createNotificationChannel(ch); } catch (Exception ignored) {}
        }
    }

    private PendingIntent actionIntent(String action, int code) {
        Intent i = new Intent(this, PlayerService.class);
        i.setAction(action);
        return PendingIntent.getService(this, code, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private Notification buildNotification() {
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent content = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            b = new Notification.Builder(this, CH_ID);
        } else {
            b = new Notification.Builder(this);
        }
        android.graphics.drawable.Icon actIcon =
                android.graphics.drawable.Icon.createWithResource(this, R.drawable.ic_notification);
        b.setSmallIcon(R.drawable.ic_notification)
         .setContentTitle(currentTitle.isEmpty() ? "CD Player" : currentTitle)
         .setContentText(currentArtist.isEmpty() ? "" : currentArtist)
         .setContentIntent(content)
         .setOngoing(playing)
         .setVisibility(Notification.VISIBILITY_PUBLIC)
         .setShowWhen(false)
         .addAction(new Notification.Action.Builder(actIcon, "Prev", actionIntent(ACTION_PREV, 1)).build())
         .addAction(new Notification.Action.Builder(actIcon, playing ? "Pause" : "Play",
                 actionIntent(playing ? ACTION_PAUSE : ACTION_PLAY, 2)).build())
         .addAction(new Notification.Action.Builder(actIcon, "Next", actionIntent(ACTION_NEXT, 3)).build())
         .setStyle(new Notification.MediaStyle()
                 .setMediaSession(session.getSessionToken())
                 .setShowActionsInCompactView(0, 1, 2));
        return b.build();
    }

    private void refreshNotification() {
        try {
            Notification n = buildNotification();
            notifManager.notify(NOTIF_ID, n);
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, n,
                        android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
            } else {
                startForeground(NOTIF_ID, n);
            }
        } catch (Exception ignored) {}
    }

    private void updateSession() {
        try {
            int state = buffering ? PlaybackState.STATE_BUFFERING
                    : (playing ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED);
            long pos = getSafePosition();
            if (pos < 0) pos = 0;
            PlaybackState.Builder sb = new PlaybackState.Builder()
                    .setActions(PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE
                            | PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS
                            | PlaybackState.ACTION_SEEK_TO | PlaybackState.ACTION_STOP)
                    .setState(state, pos, 1.0f);
            session.setPlaybackState(sb.build());

            android.media.MediaMetadata.Builder mb = new android.media.MediaMetadata.Builder()
                    .putString(android.media.MediaMetadata.METADATA_KEY_TITLE,
                            currentTitle.isEmpty() ? "CD Player" : currentTitle)
                    .putString(android.media.MediaMetadata.METADATA_KEY_ARTIST, currentArtist)
                    .putString(android.media.MediaMetadata.METADATA_KEY_ALBUM, currentArtist);
            int d = getSafeDuration();
            if (d > 0) mb.putLong(android.media.MediaMetadata.METADATA_KEY_DURATION, d);
            session.setMetadata(mb.build());
        } catch (Exception ignored) {}
    }

    // ---------- 1-second ticker: re-broadcast live state, refresh session position ----------

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            if (!tickerRunning) return;
            try {
                if (playing && prepared) {
                    updateSession();
                    broadcastState();
                }
            } catch (Exception ignored) {}
            mainHandler.postDelayed(this, 1000);
        }
    };

    private void startTicker() {
        tickerRunning = true;
        mainHandler.postDelayed(ticker, 1000);
    }

    // ---------- state broadcast ----------

    private void broadcastState() {
        broadcastState(false);
    }

    private void broadcastError() {
        broadcastState(true);
    }

    private void broadcastState(boolean error) {
        try {
            Intent i = new Intent(ACTION_STATE);
            // Explicit to this app: an implicit broadcast is not delivered
            // promptly to the dynamically registered receiver on modern
            // Android, so the play/pause button only refreshed on resume.
            i.setPackage(getPackageName());
            i.putExtra("playing", playing);
            i.putExtra("buffering", buffering);
            i.putExtra("kind", kind);
            i.putExtra("title", currentTitle);
            i.putExtra("artist", currentArtist);
            i.putExtra("position", getSafePosition());
            i.putExtra("duration", getSafeDuration());
            i.putExtra("songIndex", songIndex);
            i.putExtra("stationIndex", stationIndex);
            i.putExtra("shuffle", shuffle);
            i.putExtra("repeat", repeat);
            i.putExtra("error", error);
            sendBroadcast(i);
        } catch (Exception ignored) {}
    }

    // ---------- audio focus ----------

    private void requestFocus() {
        try {
            if (focusRequest == null) {
                AudioAttributes attrs = new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build();
                focusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                        .setAudioAttributes(attrs)
                        .setOnAudioFocusChangeListener(new AudioManager.OnAudioFocusChangeListener() {
                            @Override public void onAudioFocusChange(int focusChange) {
                                if (focusChange == AudioManager.AUDIOFOCUS_LOSS
                                        || focusChange == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
                                    pause();
                                }
                            }
                        })
                        .build();
            }
            audioManager.requestAudioFocus(focusRequest);
        } catch (Exception ignored) {}
    }

    // ---------- Bluetooth disconnect: audio devices only, playing/buffering only ----------

    private final BroadcastReceiver btReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context ctx, Intent intent) {
            if (!btPause) return;
            if (!BluetoothDevice.ACTION_ACL_DISCONNECTED.equals(intent.getAction())) return;
            if (!playing && !buffering) return;
            try {
                BluetoothDevice dev = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                // On Android 12+ EXTRA_DEVICE / getBluetoothClass() need
                // BLUETOOTH_CONNECT; when the device cannot be identified
                // (null device or class) pause anyway instead of silently
                // doing nothing, so music stops when the earbuds disconnect.
                if (dev == null) { pause(); return; }
                BluetoothClass cls = dev.getBluetoothClass();
                if (cls == null || cls.getMajorDeviceClass() == BluetoothClass.Device.Major.AUDIO_VIDEO) {
                    pause();
                }
            } catch (Exception ignored) {}
        }
    };
}
