package com.midnightstudio.cdplayer;

import android.net.Uri;

/** One local song from MediaStore. Plain data holder, no Android logic. */
public class Song {
    public final long id;
    public final String title;
    public final String artist;
    public final String album;
    public final long durationMs;
    public final Uri uri;

    public Song(long id, String title, String artist, String album, long durationMs, Uri uri) {
        this.id = id;
        this.title = title;
        this.artist = artist;
        this.album = album;
        this.durationMs = durationMs;
        this.uri = uri;
    }
}
