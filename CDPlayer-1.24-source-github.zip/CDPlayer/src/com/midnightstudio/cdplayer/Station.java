package com.midnightstudio.cdplayer;

/** One user-added radio station: a display name and a stream URL. */
public class Station {
    public final String name;
    public final String url;

    public Station(String name, String url) {
        this.name = name;
        this.url = url;
    }

    /** Escape one string for our hand-rolled JSON store. */
    public static String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"")
                .replace("\n", " ").replace("\r", " ");
    }

    /** Serialize a station list to a JSON array string. */
    public static String toJson(java.util.List<Station> list) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < list.size(); i++) {
            if (i > 0) sb.append(",");
            Station s = list.get(i);
            sb.append("{\"name\":\"").append(esc(s.name))
              .append("\",\"url\":\"").append(esc(s.url)).append("\"}");
        }
        sb.append("]");
        return sb.toString();
    }

    /** Parse a JSON array string back into stations. Tolerates bad input. */
    public static java.util.List<Station> parse(String json) {
        java.util.List<Station> out = new java.util.ArrayList<>();
        if (json == null || json.length() < 4) return out;
        try {
            int i = 0;
            while (true) {
                int n0 = json.indexOf("\"name\":\"", i);
                if (n0 < 0) break;
                int n1 = json.indexOf("\"", n0 + 8);
                if (n1 < 0) break;
                int u0 = json.indexOf("\"url\":\"", n1);
                if (u0 < 0) break;
                int u1 = json.indexOf("\"", u0 + 7);
                if (u1 < 0) break;
                String name = unesc(json.substring(n0 + 8, n1));
                String url = unesc(json.substring(u0 + 7, u1));
                if (!name.isEmpty() && !url.isEmpty()) out.add(new Station(name, url));
                i = u1 + 1;
            }
        } catch (Exception ignored) {}
        return out;
    }

    private static String unesc(String s) {
        return s.replace("\\\"", "\"").replace("\\\\", "\\");
    }
}
