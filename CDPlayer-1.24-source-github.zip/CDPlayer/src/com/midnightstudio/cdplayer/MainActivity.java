package com.midnightstudio.cdplayer;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.ContentUris;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * CD Player main screen. All code here is original, written for this app.
 *
 * - CD mode: spinning jewel-case disc (photo reference). Cassette mode:
 *   spinning reels. Mode switch never touches playback.
 * - Local music (MediaStore) with search; custom radio only (user-added
 *   stations, no presets).
 * - One animation tick drives disc/reels/progress; it is re-posted in
 *   onResume and re-syncs from the LIVE service state (the frozen-disc
 *   lesson: a tick killed in onPause and never restarted in onResume
 *   leaves the disc and progress frozen).
 * - Top bar clears the S24 camera cutout via window insets.
 */
public class MainActivity extends Activity {

    private static final String PREFS = "cdplayer_prefs";
    private static final int REQ_PERM = 1001;

    private LinearLayout root;
    private Button tabMusicBtn;
    private Button tabRadioBtn;
    private Button addStationBtn;
    private Button playAllBtn;
    private DiscView discView;
    private CassetteView cassetteView;
    private TextView titleView;
    private TextView artistView;
    private TextView curTimeView;
    private TextView totalTimeView;
    private SeekBar seekBar;
    private Button playBtn;
    private Button prevBtn;
    private Button nextBtn;
    private Button shuffleBtn;
    private Button repeatBtn;
    private EditText searchBox;
    private ListView listView;
    private TextView emptyView;

    private SharedPreferences prefs;
    private PlayerService service;
    private boolean bound = false;

    private List<Song> allSongs = new ArrayList<>();
    private List<Song> shownSongs = new ArrayList<>();
    private List<Station> stations = new ArrayList<>();
    private List<Station> shownStations = new ArrayList<>();

    private String mode = "cd";       // "cd" | "cassette"
    private String tab = "music";     // "music" | "radio"

    private final Handler tickHandler = new Handler(Looper.getMainLooper());
    private float discAngle = 0f;
    private boolean dragging = false;
    private boolean lastPlaying = false;
    private int lastKind = PlayerService.KIND_NONE;
    private String lastTitle = "";
    private String lastArtist = "";
    private boolean lastBuffering = false;
    private boolean lastError = false;

    private final ItemAdapter adapter = new ItemAdapter();

    // ---------- lifecycle ----------

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        mode = prefs.getString("mode", "cd");
        tab = prefs.getString("tab", "music");
        stations = Station.parse(prefs.getString("stations", "[]"));
        shownStations = new ArrayList<>(stations);

        buildUi();
        // Load the song list synchronously BEFORE the list first renders,
        // so the songs show right away instead of an empty list until a
        // later retry. loadSongs() runs on the main thread and retries a
        // few times if the first query comes back empty on a cold start.
        loadSongs();
        applyMode();
        applyTab();

        // Start + bind the playback service (it survives the Activity).
        Intent si = new Intent(this, PlayerService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(si);
        else startService(si);
        bindService(si, conn, BIND_AUTO_CREATE);

        // Android 14+ (API 34+) requires dynamically-registered receivers to
        // declare exported-ness; the 2-arg registerReceiver throws
        // SecurityException when targeting API 34+. ACTION_STATE is only
        // broadcast inside this app, so NOT_EXPORTED is correct.
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(stateReceiver, new IntentFilter(PlayerService.ACTION_STATE),
                    Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(stateReceiver, new IntentFilter(PlayerService.ACTION_STATE));
        }
        requestPermissionsIfNeeded();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Re-post the animation tick and re-sync from the LIVE service state.
        tickHandler.removeCallbacks(animTick);
        tickHandler.post(animTick);
        syncFromService();
        // Retry the song list if it never loaded (e.g. the first load ran
        // before the audio permission was granted): an empty list means no
        // songs to show, tap, or play, so retry every time we come back.
        if (allSongs.isEmpty()) loadSongs();
    }

    @Override
    protected void onPause() {
        super.onPause();
        tickHandler.removeCallbacks(animTick);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try { unregisterReceiver(stateReceiver); } catch (Exception ignored) {}
        if (bound) {
            try { unbindService(conn); } catch (Exception ignored) {}
            bound = false;
        }
    }

    // ---------- service connection ----------

    private final ServiceConnection conn = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName n, IBinder b) {
            service = ((PlayerService.LocalBinder) b).getService();
            bound = true;
            try {
                service.setSongList(allSongs);
                service.setStationList(stations);
            } catch (Exception ignored) {}
            syncFromService();
        }
        @Override public void onServiceDisconnected(ComponentName n) {
            bound = false;
            service = null;
        }
    };

    // ---------- UI construction (programmatic) ----------

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF0E0E0E);
        int side = dp(12);
        root.setPadding(side, 0, side, 0);
        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
                int top = insets.getSystemWindowInsetTop();
                if (insets.getDisplayCutout() != null) {
                    top = Math.max(top, insets.getDisplayCutout().getSafeInsetTop());
                }
                int bottom = insets.getSystemWindowInsetBottom();
                root.setPadding(dp(12), top + dp(4), dp(12), bottom + dp(4));
                return insets;
            }
        });
        root.setOnClickListener(null);
        setContentView(root);
        root.requestApplyInsets();

        // Top bar: title only (mode buttons moved down into the tabs row, 1.8).
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView appTitle = new TextView(this);
        appTitle.setText("\uD83D\uDCBF CD Player");
        appTitle.setTextSize(20);
        appTitle.setTypeface(null, Typeface.BOLD);
        appTitle.setTextColor(0xFFF2F2F2);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        top.addView(appTitle, titleLp);
        // Settings button (1.24): opens the Settings dialog. The mode is
        // switched only from there now (the [CD] / [Cassette] tab buttons
        // were removed in 1.24).
        Button settingsBtn = makeSmallButton("\u2699");
        settingsBtn.setTextSize(16);
        settingsBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showSettingsDialog(); }
        });
        top.addView(settingsBtn);
        root.addView(top, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // Tabs row: [Music] [Radio] [+ Add station] (1.24: the [CD] and
        // [Cassette] mode buttons were removed from this row; the mode is
        // now switched only from the Settings dialog).
        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        tabs.setGravity(Gravity.CENTER_VERTICAL);
        tabMusicBtn = makeSmallButton(getString(R.string.tab_music));
        tabRadioBtn = makeSmallButton(getString(R.string.tab_radio));
        addStationBtn = makeSmallButton(getString(R.string.add_station_short));
        tabMusicBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { setTab("music"); }
        });
        tabRadioBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { setTab("radio"); }
        });
        addStationBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showAddStationDialog(); }
        });
        tabs.addView(tabMusicBtn);
        tabs.addView(tabRadioBtn);
        LinearLayout.LayoutParams addLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        addLp.leftMargin = dp(4);
        tabs.addView(addStationBtn, addLp);
        LinearLayout.LayoutParams tabsLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tabsLp.topMargin = dp(8);
        root.addView(tabs, tabsLp);

        // Disc / cassette area.
        FrameLayout discArea = new FrameLayout(this);
        discView = new DiscView(this);
        cassetteView = new CassetteView(this);
        discArea.addView(discView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        discArea.addView(cassetteView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        LinearLayout.LayoutParams discLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(300));
        discLp.topMargin = dp(10);
        root.addView(discArea, discLp);

        // Now playing.
        titleView = new TextView(this);
        titleView.setTextSize(18);
        titleView.setTypeface(null, Typeface.BOLD);
        titleView.setTextColor(0xFFF2F2F2);
        titleView.setSingleLine(true);
        titleView.setEllipsize(android.text.TextUtils.TruncateAt.MARQUEE);
        titleView.setMarqueeRepeatLimit(-1);
        titleView.setSelected(true);
        titleView.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams titleLp2 = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        titleLp2.topMargin = dp(10);
        root.addView(titleView, titleLp2);

        artistView = new TextView(this);
        artistView.setTextSize(14);
        artistView.setTextColor(0xFF9A9A9A);
        artistView.setSingleLine(true);
        artistView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        artistView.setGravity(Gravity.CENTER);
        root.addView(artistView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // Progress row.
        LinearLayout prog = new LinearLayout(this);
        prog.setOrientation(LinearLayout.HORIZONTAL);
        prog.setGravity(Gravity.CENTER_VERTICAL);
        curTimeView = new TextView(this);
        curTimeView.setText("0:00");
        curTimeView.setTextSize(12);
        curTimeView.setTextColor(0xFF9A9A9A);
        totalTimeView = new TextView(this);
        totalTimeView.setText("0:00");
        totalTimeView.setTextSize(12);
        totalTimeView.setTextColor(0xFF9A9A9A);
        seekBar = new SeekBar(this);
        seekBar.setMax(0);
        seekBar.setEnabled(false);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                if (fromUser && dragging) curTimeView.setText(fmt(p));
            }
            @Override public void onStartTrackingTouch(SeekBar sb) { dragging = true; }
            @Override public void onStopTrackingTouch(SeekBar sb) {
                dragging = false;
                if (service != null) service.seekTo(sb.getProgress());
            }
        });
        LinearLayout.LayoutParams seekLp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        seekLp.leftMargin = dp(8);
        seekLp.rightMargin = dp(8);
        prog.addView(curTimeView);
        prog.addView(seekBar, seekLp);
        prog.addView(totalTimeView);
        LinearLayout.LayoutParams progLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        progLp.topMargin = dp(8);
        root.addView(prog, progLp);

        // Transport row.
        LinearLayout transport = new LinearLayout(this);
        transport.setOrientation(LinearLayout.HORIZONTAL);
        transport.setGravity(Gravity.CENTER);
        shuffleBtn = makeTransportButton("\u21C4");
        prevBtn = makeTransportButton("\u25C0\u25C0");
        prevBtn.setTextSize(18);
        playBtn = makeTransportButton("\u25B6");
        playBtn.setTextSize(30);
        nextBtn = makeTransportButton("\u25B6\u25B6");
        nextBtn.setTextSize(18);
        repeatBtn = makeTransportButton("\u21BB");
        shuffleBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (service != null) service.toggleShuffle();
                applyStateToUi();
            }
        });
        prevBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (service != null) service.prev();
            }
        });
        playBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (service != null) service.togglePlayPause();
                // Re-read the LIVE state at once so the button flips
                // immediately instead of waiting for the broadcast.
                syncFromService();
            }
        });
        nextBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (service != null) service.next();
            }
        });
        repeatBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (service != null) service.cycleRepeat();
                applyStateToUi();
            }
        });
        transport.addView(shuffleBtn);
        transport.addView(prevBtn);
        transport.addView(playBtn);
        transport.addView(nextBtn);
        transport.addView(repeatBtn);
        LinearLayout.LayoutParams trLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        trLp.topMargin = dp(4);
        root.addView(transport, trLp);

        // Play All row (Music tab only).
        LinearLayout playAllRow = new LinearLayout(this);
        playAllRow.setOrientation(LinearLayout.HORIZONTAL);
        playAllRow.setGravity(Gravity.CENTER_VERTICAL);
        playAllBtn = makeSmallButton("\u25B6 \uBAA8\uB450 \uC7AC\uC0DD");
        playAllBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (service != null && !allSongs.isEmpty()) {
                    service.playSong(allSongs.get(0), allSongs, 0);
                }
            }
        });
        playAllRow.addView(playAllBtn);
        LinearLayout.LayoutParams paLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        paLp.topMargin = dp(10);
        root.addView(playAllRow, paLp);

        // Search box.
        searchBox = new EditText(this);
        searchBox.setHint(R.string.search_hint);
        searchBox.setTextColor(0xFFF2F2F2);
        searchBox.setHintTextColor(0xFF9A9A9A);
        searchBox.setSingleLine(true);
        searchBox.setBackgroundColor(0xFF1C1C1C);
        searchBox.setPadding(dp(10), dp(8), dp(10), dp(8));
        searchBox.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) { applyFilter(s.toString()); }
        });
        LinearLayout.LayoutParams searchLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        searchLp.topMargin = dp(6);
        root.addView(searchBox, searchLp);

        // List.
        listView = new ListView(this);
        listView.setAdapter(adapter);
        listView.setDivider(null);
        listView.setDividerHeight(0);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override public void onItemClick(AdapterView<?> parent, View view, int pos, long id) {
                onItemTap(pos);
            }
        });
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override public boolean onItemLongClick(AdapterView<?> parent, View view, int pos, long id) {
                return onItemLongPress(pos);
            }
        });
        LinearLayout.LayoutParams listLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        listLp.topMargin = dp(6);
        root.addView(listView, listLp);

        emptyView = new TextView(this);
        emptyView.setText(R.string.no_songs);
        emptyView.setTextColor(0xFF9A9A9A);
        emptyView.setGravity(Gravity.CENTER);
        emptyView.setVisibility(View.GONE);
        root.addView(emptyView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    private Button makeSmallButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(13);
        b.setTextColor(0xFFF2F2F2);
        b.setBackgroundColor(0xFF2A2A2A);
        // A plain Button keeps the theme's 88dp minWidth even with
        // WRAP_CONTENT, so five tabs were at least 440dp wide and the last
        // one (the + button) was pushed off the 336dp-wide row. Allow shrinking
        // to the text width and use 8dp side padding so the row fits.
        b.setMinimumWidth(0);
        b.setMinWidth(0);
        b.setPadding(dp(8), dp(6), dp(8), dp(6));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.rightMargin = dp(4);
        b.setLayoutParams(lp);
        return b;
    }

    private Button makeTransportButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(22);
        b.setTextColor(0xFFF2F2F2);
        b.setBackgroundColor(Color.TRANSPARENT);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                dp(56), dp(56));
        lp.leftMargin = dp(4);
        lp.rightMargin = dp(4);
        b.setLayoutParams(lp);
        return b;
    }

    // ---------- mode / tab ----------

    private void setMode(String m) {
        mode = m;
        prefs.edit().putString("mode", mode).commit();
        applyMode();
    }

    private void applyMode() {
        boolean cd = "cd".equals(mode);
        discView.setVisibility(cd ? View.VISIBLE : View.GONE);
        cassetteView.setVisibility(cd ? View.GONE : View.VISIBLE);
    }

    private void setTab(String t) {
        tab = t;
        prefs.edit().putString("tab", tab).commit();
        applyTab();
    }

    private void applyTab() {
        boolean music = "music".equals(tab);
        tabMusicBtn.setBackgroundColor(music ? 0xFF4A4A4A : 0xFF2A2A2A);
        tabRadioBtn.setBackgroundColor(music ? 0xFF2A2A2A : 0xFF4A4A4A);
        addStationBtn.setVisibility(music ? View.GONE : View.VISIBLE);
        playAllBtn.setVisibility(music ? View.VISIBLE : View.GONE);
        searchBox.setHint(music ? R.string.search_hint : R.string.search_station_hint);
        searchBox.setText("");
        applyFilter("");
        refreshEmpty();
        // Retry the song list when opening the Music tab with nothing loaded.
        if (music && allSongs.isEmpty()) loadSongs();
    }

    // ---------- list data ----------

    private void applyFilter(String q) {
        String query = q == null ? "" : q.trim().toLowerCase(Locale.getDefault());
        if ("music".equals(tab)) {
            shownSongs = new ArrayList<>();
            for (Song s : allSongs) {
                if (query.isEmpty()
                        || s.title.toLowerCase(Locale.getDefault()).contains(query)
                        || s.artist.toLowerCase(Locale.getDefault()).contains(query)) {
                    shownSongs.add(s);
                }
            }
        } else {
            shownStations = new ArrayList<>();
            for (Station s : stations) {
                if (query.isEmpty()
                        || s.name.toLowerCase(Locale.getDefault()).contains(query)
                        || s.url.toLowerCase(Locale.getDefault()).contains(query)) {
                    shownStations.add(s);
                }
            }
        }
        adapter.notifyDataSetChanged();
        refreshEmpty();
    }

    private void refreshEmpty() {
        boolean empty = "music".equals(tab) ? shownSongs.isEmpty() : shownStations.isEmpty();
        emptyView.setVisibility(empty ? View.VISIBLE : View.GONE);
        emptyView.setText("music".equals(tab) ? R.string.no_songs : R.string.no_stations);
    }

    private void onItemTap(int pos) {
        if (service == null) return;
        try {
            if ("music".equals(tab)) {
                if (pos < 0 || pos >= shownSongs.size()) return;
                Song s = shownSongs.get(pos);
                service.playSong(s, shownSongs, pos);
            } else {
                if (pos < 0 || pos >= shownStations.size()) return;
                Station st = shownStations.get(pos);
                service.playStation(st, shownStations, pos);
            }
        } catch (Exception ignored) {}
    }

    private boolean onItemLongPress(int pos) {
        if (!"radio".equals(tab)) return false;
        if (pos < 0 || pos >= shownStations.size()) return false;
        final Station st = shownStations.get(pos);
        new AlertDialog.Builder(this)
                .setTitle(R.string.delete_station_title)
                .setMessage(getString(R.string.delete_station_msg))
                .setPositiveButton(R.string.delete, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        deleteStation(st);
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
        return true;
    }

    private void deleteStation(Station st) {
        stations.remove(st);
        persistStations();
        applyFilter(searchBox.getText().toString());
        if (service != null) service.setStationList(stations);
        Toast.makeText(this, R.string.station_deleted, Toast.LENGTH_SHORT).show();
    }

    private void persistStations() {
        prefs.edit().putString("stations", Station.toJson(stations)).commit();
    }

    // Settings dialog (1.24): Bluetooth disconnect pause toggle + CD /
    // cassette mode switch. Opening or closing it never stops playback
    // and never changes the song, station or tab. The mode is switched
    // only from here now (the [CD] / [Cassette] tab buttons were removed
    // in 1.24); picking a mode calls the same setMode() as before, so the
    // disc / cassette views stay in sync.
    private void showSettingsDialog() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(20), dp(8), dp(20), dp(8));

        // Bluetooth disconnect pause toggle (service persists "bt_pause").
        final Switch btSwitch = new Switch(this);
        btSwitch.setText(R.string.settings_bt_pause);
        btSwitch.setTextColor(0xFFF2F2F2);
        boolean btOn = (service != null) ? service.isBtPause()
                : prefs.getBoolean("bt_pause", true);
        btSwitch.setChecked(btOn);
        btSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean on) {
                if (service != null) service.setBtPause(on);
                else prefs.edit().putBoolean("bt_pause", on).commit();
            }
        });
        layout.addView(btSwitch, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // CD / cassette mode switch.
        final RadioGroup modeGroup = new RadioGroup(this);
        modeGroup.setOrientation(RadioGroup.VERTICAL);
        final RadioButton cdBtn = new RadioButton(this);
        cdBtn.setText(R.string.settings_mode_cd);
        cdBtn.setTextColor(0xFFF2F2F2);
        cdBtn.setId(View.generateViewId());
        final RadioButton cassetteBtn = new RadioButton(this);
        cassetteBtn.setText(R.string.settings_mode_cassette);
        cassetteBtn.setTextColor(0xFFF2F2F2);
        cassetteBtn.setId(View.generateViewId());
        modeGroup.addView(cdBtn);
        modeGroup.addView(cassetteBtn);
        if ("cassette".equals(mode)) cassetteBtn.setChecked(true);
        else cdBtn.setChecked(true);
        modeGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(RadioGroup g, int checkedId) {
                if (checkedId == cdBtn.getId()) setMode("cd");
                else if (checkedId == cassetteBtn.getId()) setMode("cassette");
            }
        });
        LinearLayout.LayoutParams groupLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        groupLp.topMargin = dp(16);
        layout.addView(modeGroup, groupLp);

        new AlertDialog.Builder(this)
                .setTitle(R.string.settings_title)
                .setView(layout)
                .setNegativeButton(R.string.settings_close, null)
                .show();
    }

    private void showAddStationDialog() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(20), dp(8), dp(20), dp(8));
        final EditText nameBox = new EditText(this);
        nameBox.setHint(R.string.station_name_hint);
        nameBox.setSingleLine(true);
        final EditText urlBox = new EditText(this);
        urlBox.setHint(R.string.station_url_hint);
        urlBox.setSingleLine(true);
        urlBox.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        layout.addView(nameBox, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams urlLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        urlLp.topMargin = dp(10);
        layout.addView(urlBox, urlLp);

        new AlertDialog.Builder(this)
                .setTitle(R.string.add_station)
                .setView(layout)
                .setPositiveButton(R.string.add, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        String name = nameBox.getText().toString().trim();
                        String url = urlBox.getText().toString().trim();
                        if (name.isEmpty() || url.isEmpty()) {
                            Toast.makeText(MainActivity.this, R.string.need_name_url,
                                    Toast.LENGTH_SHORT).show();
                            return;
                        }
                        if (!url.startsWith("http://") && !url.startsWith("https://")) {
                            Toast.makeText(MainActivity.this, R.string.need_url,
                                    Toast.LENGTH_SHORT).show();
                            return;
                        }
                        Station st = new Station(name, url);
                        stations.add(st);
                        persistStations();
                        applyFilter(searchBox.getText().toString());
                        if (service != null) service.setStationList(stations);
                        Toast.makeText(MainActivity.this, R.string.station_added,
                                Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    // ---------- permissions + MediaStore ----------

    private void requestPermissionsIfNeeded() {
        List<String> need = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(Manifest.permission.READ_MEDIA_AUDIO)
                    != PackageManager.PERMISSION_GRANTED) {
                need.add(Manifest.permission.READ_MEDIA_AUDIO);
            }
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                need.add(Manifest.permission.POST_NOTIFICATIONS);
            }
        } else {
            if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                need.add(Manifest.permission.READ_EXTERNAL_STORAGE);
            }
        }
        if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)
                != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.BLUETOOTH_CONNECT);
        }
        if (!need.isEmpty()) {
            requestPermissions(need.toArray(new String[0]), REQ_PERM);
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == REQ_PERM) {
            boolean audioOk = false;
            for (int i = 0; i < perms.length; i++) {
                if ((Manifest.permission.READ_MEDIA_AUDIO.equals(perms[i])
                        || Manifest.permission.READ_EXTERNAL_STORAGE.equals(perms[i]))
                        && results[i] == PackageManager.PERMISSION_GRANTED) {
                    audioOk = true;
                }
            }
            if (audioOk) loadSongs();
            else Toast.makeText(this, R.string.perm_needed, Toast.LENGTH_SHORT).show();
        }
    }

    private void loadSongs() {
        // Synchronous load: the list must be ready before the list first
        // renders, so the query runs on the calling (main) thread instead
        // of a background thread. On a cold start the first MediaStore
        // query can return empty (provider not ready yet), so retry a few
        // times with a short pause when the audio permission is already
        // granted and the result came back empty. Worst-case block is
        // about 300 ms plus query time, far under ANR limits, and this
        // only retries when the list is empty. When the permission is not
        // granted yet there is no point retrying; the permission-result
        // handler reloads after the user grants it.
        List<Song> found = querySongs();
        if (found.isEmpty() && hasAudioPermission()) {
            for (int i = 0; i < 3 && found.isEmpty(); i++) {
                try { Thread.sleep(100); } catch (InterruptedException ignored) {}
                found = querySongs();
            }
        }
        allSongs = found;
        applyFilter(searchBox.getText().toString());
        if (service != null) service.setSongList(allSongs);
    }

    private boolean hasAudioPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            return checkSelfPermission(Manifest.permission.READ_MEDIA_AUDIO)
                    == PackageManager.PERMISSION_GRANTED;
        }
        return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED;
    }

    private List<Song> querySongs() {
        List<Song> found = new ArrayList<>();
        try {
            String[] proj = {
                    MediaStore.Audio.Media._ID,
                    MediaStore.Audio.Media.TITLE,
                    MediaStore.Audio.Media.ARTIST,
                    MediaStore.Audio.Media.ALBUM,
                    MediaStore.Audio.Media.DURATION
            };
            String sel = MediaStore.Audio.Media.IS_MUSIC + "=1 AND "
                    + MediaStore.Audio.Media.DURATION + ">0";
            Cursor cur = getContentResolver().query(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                    proj, sel, null,
                    MediaStore.Audio.Media.TITLE + " ASC");
            if (cur != null) {
                int idCol = cur.getColumnIndex(MediaStore.Audio.Media._ID);
                int titleCol = cur.getColumnIndex(MediaStore.Audio.Media.TITLE);
                int artistCol = cur.getColumnIndex(MediaStore.Audio.Media.ARTIST);
                int albumCol = cur.getColumnIndex(MediaStore.Audio.Media.ALBUM);
                int durCol = cur.getColumnIndex(MediaStore.Audio.Media.DURATION);
                while (cur.moveToNext()) {
                    long id = cur.getLong(idCol);
                    String title = cur.getString(titleCol);
                    String artist = cur.getString(artistCol);
                    String album = cur.getString(albumCol);
                    long dur = cur.getLong(durCol);
                    if (title == null || title.isEmpty()) title = "Unknown";
                    if (artist == null || artist.isEmpty()) artist = "";
                    if (album == null) album = "";
                    Uri uri = ContentUris.withAppendedId(
                            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id);
                    found.add(new Song(id, title, artist, album, dur, uri));
                }
                cur.close();
            }
        } catch (Exception ignored) {}
        return found;
    }

    // ---------- state sync ----------

    private final BroadcastReceiver stateReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context ctx, Intent intent) {
            if (intent == null) return;
            lastPlaying = intent.getBooleanExtra("playing", false);
            lastBuffering = intent.getBooleanExtra("buffering", false);
            lastKind = intent.getIntExtra("kind", PlayerService.KIND_NONE);
            lastTitle = intent.getStringExtra("title");
            lastArtist = intent.getStringExtra("artist");
            lastError = intent.getBooleanExtra("error", false);
            if (lastTitle == null) lastTitle = "";
            if (lastArtist == null) lastArtist = "";
            applyStateToUi();
            if (lastError && lastKind == PlayerService.KIND_RADIO) {
                Toast.makeText(MainActivity.this, R.string.radio_error,
                        Toast.LENGTH_SHORT).show();
            }
        }
    };

    /** Re-read the LIVE service state (onResume / onServiceConnected). */
    private void syncFromService() {
        if (service == null) return;
        try {
            lastPlaying = service.isPlaying();
            lastBuffering = service.isBuffering();
            lastKind = service.getKind();
            lastTitle = service.getCurrentTitle();
            lastArtist = service.getCurrentArtist();
            if (lastTitle == null) lastTitle = "";
            if (lastArtist == null) lastArtist = "";
            applyStateToUi();
        } catch (Exception ignored) {}
    }

    private void applyStateToUi() {
        titleView.setText(lastTitle.isEmpty() ? "CD Player" : lastTitle);
        if (discView != null) discView.setTitle(lastTitle);
        if (lastBuffering) {
            artistView.setText(R.string.buffering);
        } else {
            artistView.setText(lastArtist);
        }
        playBtn.setText(lastPlaying ? "\u275A\u275A" : "\u25B6");
        if (service != null) {
            boolean shuf = service.isShuffle();
            shuffleBtn.setBackgroundColor(shuf ? 0xFF3A6EA5 : Color.TRANSPARENT);
            shuffleBtn.setTextColor(shuf ? 0xFFFFFFFF : 0xFFF2F2F2);
            int rep = service.getRepeat();
            boolean repOn = rep != PlayerService.REPEAT_OFF;
            repeatBtn.setBackgroundColor(repOn ? 0xFF3A6EA5 : Color.TRANSPARENT);
            repeatBtn.setTextColor(repOn ? 0xFFFFFFFF : 0xFFF2F2F2);
            repeatBtn.setText(rep == PlayerService.REPEAT_ONE ? "\u21BB1" : "\u21BB");
        }
        if (lastKind == PlayerService.KIND_RADIO) {
            seekBar.setEnabled(false);
            seekBar.setMax(0);
            seekBar.setProgress(0);
            curTimeView.setText(getString(R.string.live));
            totalTimeView.setText("");
        } else {
            seekBar.setEnabled(true);
            int d = service != null ? service.getSafeDuration() : -1;
            if (d > 0) seekBar.setMax(d);
            totalTimeView.setText(d > 0 ? fmt(d) : "0:00");
        }
        adapter.notifyDataSetChanged();
    }

    // ---------- the one animation tick: disc, reels, progress ----------

    private final Runnable animTick = new Runnable() {
        @Override public void run() {
            try {
                // Spin while playing OR while buffering/connecting, so the
                // disc starts turning the moment playback is requested
                // (a radio tap broadcasts buffering=true right away) and
                // stops only when paused/stopped (both flags false).
                if (lastPlaying || lastBuffering) {
                    discAngle += 9f; // 100ms of a 4s revolution
                    if (discAngle >= 360f) discAngle -= 360f;
                    discView.setAngle(discAngle);
                    cassetteView.setAngle(discAngle);
                }
                if (!dragging && service != null && lastKind == PlayerService.KIND_LOCAL) {
                    int pos = service.getSafePosition();
                    int dur = service.getSafeDuration();
                    if (pos >= 0) {
                        seekBar.setProgress(pos);
                        curTimeView.setText(fmt(pos));
                    }
                    if (dur > 0 && seekBar.getMax() != dur) {
                        seekBar.setMax(dur);
                        totalTimeView.setText(fmt(dur));
                    }
                }
            } catch (Exception ignored) {}
            tickHandler.postDelayed(this, 100);
        }
    };

    private String fmt(int ms) {
        int s = Math.max(0, ms / 1000);
        return (s / 60) + ":" + String.format(Locale.US, "%02d", s % 60);
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    // ---------- list adapter ----------

    private class ItemAdapter extends BaseAdapter {
        @Override public int getCount() {
            return "music".equals(tab) ? shownSongs.size() : shownStations.size();
        }
        @Override public Object getItem(int pos) {
            return "music".equals(tab) ? shownSongs.get(pos) : shownStations.get(pos);
        }
        @Override public long getItemId(int pos) { return pos; }

        @Override public View getView(int pos, View convert, ViewGroup parent) {
            LinearLayout row;
            TextView t1, t2;
            if (convert instanceof LinearLayout && convert.getTag() instanceof TextView[]) {
                row = (LinearLayout) convert;
                TextView[] tags = (TextView[]) convert.getTag();
                t1 = tags[0];
                t2 = tags[1];
            } else {
                row = new LinearLayout(MainActivity.this);
                row.setOrientation(LinearLayout.VERTICAL);
                row.setPadding(dp(8), dp(10), dp(8), dp(10));
                t1 = new TextView(MainActivity.this);
                t1.setTextSize(16);
                t1.setTextColor(0xFFF2F2F2);
                t1.setSingleLine(true);
                t1.setEllipsize(android.text.TextUtils.TruncateAt.END);
                t2 = new TextView(MainActivity.this);
                t2.setTextSize(13);
                t2.setTextColor(0xFF9A9A9A);
                t2.setSingleLine(true);
                t2.setEllipsize(android.text.TextUtils.TruncateAt.END);
                row.addView(t1);
                row.addView(t2);
                row.setTag(new TextView[]{t1, t2});
            }
            boolean isCurrent = false;
            if ("music".equals(tab)) {
                Song s = shownSongs.get(pos);
                t1.setText(s.title);
                t2.setText(s.artist);
                if (service != null && lastKind == PlayerService.KIND_LOCAL
                        && service.getCurrentSong() != null
                        && service.getCurrentSong().id == s.id) {
                    isCurrent = true;
                }
            } else {
                Station st = shownStations.get(pos);
                t1.setText(st.name);
                t2.setText(st.url);
                if (service != null && lastKind == PlayerService.KIND_RADIO
                        && service.getCurrentStation() != null
                        && service.getCurrentStation().url.equals(st.url)) {
                    isCurrent = true;
                }
            }
            t1.setTypeface(null, isCurrent ? Typeface.BOLD : Typeface.NORMAL);
            t1.setTextColor(isCurrent ? 0xFF7FB3FF : 0xFFF2F2F2);
            row.setBackgroundColor(isCurrent ? 0xFF222233 : Color.TRANSPARENT);
            return row;
        }
    }
}
