# CD Player

A CD jewel-case style music player for Android, with CD and cassette modes,
local music playback, and custom radio (you enter your own stream URLs).

- Package: `com.midnightstudio.cdplayer`
- Version: 1.24 (versionCode 25)
- minSdk 26, targetSdk 37
- All code written from scratch here. The UI is built programmatically
  (no layout XML); `DiscView` and `CassetteView` are custom Canvas views.

## Features

- CD mode: spinning iridescent disc (4s/rev) with the song title drawn
  curved in a circle on the disc, real local-music progress + drag-to-seek,
  radio shows LIVE, prev/play/next, shuffle, repeat.
- Cassette mode: spinning reels, switching modes never stops playback.
- Local music: MediaStore song list with search, tap plays in order,
  "Play All" button.
- Custom radio only (no preset stations): add a station by name + stream
  URL, tap to play, long-press to delete, last station/track persisted.
- Background playback via a foreground service, media notification with
  real progress + seek for local music, ICY StreamTitle refreshes the
  notification and MediaSession metadata.
- Bluetooth disconnect pause (default ON, toggleable in Settings).
- Settings (gear button in the top bar): Bluetooth pause on/off, and the
  CD / cassette mode switch.

## Build

This project uses the plain Android command-line tools (aapt2, javac, d8,
zipalign, apksigner) rather than Gradle. You need a JDK 17 and an Android
SDK with platform android-37 and build-tools 37.0.0. The general order is:
aapt2 link -> add classes.dex -> zipalign -> apksigner sign. The
`resources.arsc` entry must be stored uncompressed (ZIP_STORED) or Android
11+ refuses to install the APK (error -124).

## Signing

The release signing key is NOT in this repo. Sign your own builds with
your own keystore. Keep your keystore and its password private and never
commit them.
